Project Based on Smart Health and Hygiene
Powered By Python3

#Global Module Used In This Project
1)wikipedia
2)covid_india
3)Pillow
4)import os
5)Tkinter
6)datetime
#Self Created Module Used In This Project
1)start_up
2)pages
3)food_and_diet
4)startmode
5)placeholder
6)variable
7)search_script
8)problem

Design & Developed By:
Yuvraj Singh Yadav
Shreyas Om

#################
Just run Bmax.py file

